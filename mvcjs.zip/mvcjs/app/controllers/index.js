var indexController = {};

indexController.index = function() {
	view('index').render();
}

